# WeatherWise
An ultimate weather companion app designed using HTML, CSS &amp; JS.
The hosted link of the project is : https://weather-wise-five-mu.vercel.app/
